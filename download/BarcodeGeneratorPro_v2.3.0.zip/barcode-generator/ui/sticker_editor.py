"""
Interactive sticker editor (v2.2.0).

ElementItem is now Illustrator-like:
  - 8 resize handles on the corners and edges
  - 1 rotate handle above the top edge
  - Drag the body to move
  - Hover shows appropriate cursor (size/rotate/move)
  - Double-click opens a small popup toolbar for font/color/etc.

The element's position is stored via setPos() (mm-based via mm_per_px),
size via setRect(0, 0, w, h). Rotation via setRotation() around center.
"""
from typing import List, Optional

from PyQt5.QtCore import (Qt, QRectF, QPointF, QSizeF,
                           pyqtSignal, QSize, QTimer, QLineF)
from PyQt5.QtGui import (QFont, QColor, QPen, QBrush, QPainter, QPixmap,
                          QImage, QTransform, QFontDatabase, QIcon,
                          QStandardItem, QStandardItemModel, QCursor)
from PyQt5.QtWidgets import (
    QDialog, QDialogButtonBox, QVBoxLayout, QHBoxLayout, QFormLayout,
    QWidget, QLabel, QLineEdit, QDoubleSpinBox, QSpinBox, QCheckBox,
    QComboBox, QPushButton, QGroupBox, QSplitter, QMessageBox, QListWidget,
    QListWidgetItem, QFrame, QSizePolicy, QScrollArea, QSlider, QTabWidget,
    QGraphicsScene, QGraphicsView, QGraphicsRectItem, QGraphicsItem,
    QGraphicsEllipseItem, QGraphicsTextItem, QColorDialog,
    QToolTip, QApplication
)

from core.templates import (StickerTemplate, StickerElement,
                              default_template, get_text_for_element,
                              enabled_elements)
from core.units import (MM, IN, get_unit, format_value, pt_to_mm, mm_to_pt)
from core.barcode_gen import generate_ean13_image, make_full_ean13
from core.printer import (draw_sticker_with_template,
                            render_single_sticker_preview, _draw_element_at_origin)


# Handle size in pixels (rendered as small squares)
HANDLE_SIZE = 8
ROTATE_HANDLE_DISTANCE = 24


# Handle IDs — 4 corners + 4 edges + rotate
HANDLE_TOP_LEFT = 0
HANDLE_TOP = 1
HANDLE_TOP_RIGHT = 2
HANDLE_LEFT = 3
HANDLE_RIGHT = 4
HANDLE_BOTTOM_LEFT = 5
HANDLE_BOTTOM = 6
HANDLE_BOTTOM_RIGHT = 7
HANDLE_ROTATE = 8


class HandleItem(QGraphicsRectItem):
    """A small square (or circle) at a corner/edge for resizing or rotating."""
    def __init__(self, parent_item: 'ElementItem', handle_id: int):
        super().__init__(parent_item)
        self.handle_id = handle_id
        self.parent_item = parent_item
        self.setRect(-HANDLE_SIZE / 2, -HANDLE_SIZE / 2, HANDLE_SIZE, HANDLE_SIZE)
        self.setFlag(QGraphicsItem.ItemIsMovable, False)
        self.setFlag(QGraphicsItem.ItemIsSelectable, False)
        self.setAcceptHoverEvents(True)
        # Visual style
        self.setBrush(QColor('#1a4d8f'))
        pen = QPen(QColor('white'), 1)
        self.setPen(pen)
        self.setZValue(100)  # above element

    def hoverEnterEvent(self, event):
        # Set cursor based on handle type
        if self.handle_id == HANDLE_ROTATE:
            self.setCursor(Qt.CrossCursor)
        elif self.handle_id in (HANDLE_TOP_LEFT, HANDLE_BOTTOM_RIGHT):
            self.setCursor(Qt.SizeFDiagCursor)
        elif self.handle_id in (HANDLE_TOP_RIGHT, HANDLE_BOTTOM_LEFT):
            self.setCursor(Qt.SizeBDiagCursor)
        elif self.handle_id in (HANDLE_LEFT, HANDLE_RIGHT):
            self.setCursor(Qt.SizeHorCursor)
        elif self.handle_id in (HANDLE_TOP, HANDLE_BOTTOM):
            self.setCursor(Qt.SizeVerCursor)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):
        self.setCursor(Qt.ArrowCursor)
        super().hoverLeaveEvent(event)


class ElementItem(QGraphicsRectItem):
    """
    Selectable, movable, resizable, rotatable element on the canvas.
    Position: setPos() (scene coords)
    Size: setRect(0, 0, w, h) — local coords, top-left at (0,0)
    Rotation: setRotation() — around center of rect
    """
    def __init__(self, element: StickerElement, mm_per_px: float,
                 parent_view: 'StickerScene'):
        super().__init__()
        self.element = element
        self.mm_per_px = mm_per_px
        self.parent_view = parent_view

        self.setFlags(QGraphicsItem.ItemIsSelectable
                      | QGraphicsItem.ItemIsMovable
                      | QGraphicsItem.ItemSendsGeometryChanges
                      | QGraphicsItem.ItemIsFocusable)
        self.setAcceptHoverEvents(True)

        # Interaction state
        self._resize_handle = None  # which handle is being dragged
        self._rotate_dragging = False
        self._resize_start_rect = QRectF()
        self._resize_start_pos = QPointF()
        self._resize_start_rot = 0.0
        self._resize_start_center = QPointF()

        # Build handles (8 resize + 1 rotate)
        self.handles: List[HandleItem] = []
        for hid in range(9):  # 0..8
            h = HandleItem(self, hid)
            self.handles.append(h)

        # Hide handles initially — show only when selected
        self._set_handles_visible(False)
        self._update_geometry()
        # Connect scene's selection change if needed

    def _update_geometry(self):
        px_per_mm = 1.0 / self.mm_per_px
        x = self.element.x_mm * px_per_mm
        y = self.element.y_mm * px_per_mm
        w = self.element.w_mm * px_per_mm
        h = self.element.h_mm * px_per_mm
        self.setPos(x, y)
        self.setRect(QRectF(0, 0, w, h))
        self.setTransformOriginPoint(w / 2, h / 2)
        self.setRotation(self.element.rotation)
        # Update handle positions
        self._update_handles()

    def _update_handles(self):
        """Position the 8 resize handles at corners/edges + rotate handle."""
        r = self.rect()
        cx = r.center().x()
        cy = r.center().y()
        # Corners
        self.handles[HANDLE_TOP_LEFT].setPos(r.left(), r.top())
        self.handles[HANDLE_TOP_RIGHT].setPos(r.right(), r.top())
        self.handles[HANDLE_BOTTOM_LEFT].setPos(r.left(), r.bottom())
        self.handles[HANDLE_BOTTOM_RIGHT].setPos(r.right(), r.bottom())
        # Edges (midpoints)
        self.handles[HANDLE_TOP].setPos(cx, r.top())
        self.handles[HANDLE_BOTTOM].setPos(cx, r.bottom())
        self.handles[HANDLE_LEFT].setPos(r.left(), cy)
        self.handles[HANDLE_RIGHT].setPos(r.right(), cy)
        # Rotate handle — above the top edge
        self.handles[HANDLE_ROTATE].setPos(cx, r.top() - ROTATE_HANDLE_DISTANCE)
        # Draw a line from top edge to rotate handle (via parent's paint)

    def _set_handles_visible(self, visible: bool):
        for h in self.handles:
            h.setVisible(visible)

    def refresh(self):
        self._update_geometry()
        self.update()

    def paint(self, painter: QPainter, option, widget=None):
        rect = self.rect()
        # Selection border
        if self.isSelected():
            pen = QPen(QColor('#1a4d8f'), 1.0)
            pen.setStyle(Qt.SolidLine)
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            painter.drawRect(rect)
            # Line from top edge to rotate handle
            cx = rect.center().x()
            painter.drawLine(QPointF(cx, rect.top()),
                             QPointF(cx, rect.top() - ROTATE_HANDLE_DISTANCE))
        else:
            # Unselected: thin dashed border
            pen = QPen(QColor('#999'), 0.5, Qt.DashLine)
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            painter.drawRect(rect)

        # Draw content (text, barcode, or logo)
        data = self.parent_view.sample_data
        px_per_mm = 1.0 / self.mm_per_px
        _draw_element_at_origin(painter, self.element, data, px_per_mm, rect)

    # ------------------------------------------------------ Selection
    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemSelectedHasChanged:
            self._set_handles_visible(self.isSelected())
            self.parent_view.element_selection_changed.emit(self.element)
            if self.isSelected():
                self.setFocus()
        elif change == QGraphicsItem.ItemPositionHasChanged:
            # pos changed due to drag — update element.x_mm/y_mm
            px_per_mm = 1.0 / self.mm_per_px
            self.element.x_mm = self.pos().x() / px_per_mm
            self.element.y_mm = self.pos().y() / px_per_mm
            self.parent_view.element_changed.emit(self.element)
        return super().itemChange(change, value)

    # ------------------------------------------------------ Hover cursor
    def hoverMoveEvent(self, event):
        # Show move cursor over body when selected
        if self.isSelected():
            pos = event.pos()  # local coords
            # If not over a handle, show move cursor
            over_handle = False
            for h in self.handles:
                if h.isVisible() and h.contains(h.mapFromItem(self, pos)):
                    over_handle = True
                    break
            if not over_handle:
                self.setCursor(Qt.SizeAllCursor)
        else:
            self.setCursor(Qt.ArrowCursor)
        super().hoverMoveEvent(event)

    # ------------------------------------------------------ Mouse press
    def mousePressEvent(self, event):
        # Check if press is on a handle
        if self.isSelected():
            pos = event.pos()  # local coords
            for h in self.handles:
                if h.isVisible():
                    h_pos = h.mapFromItem(self, pos)
                    if h.rect().contains(h_pos) or h.contains(h_pos):
                        # Start resize or rotate
                        if h.handle_id == HANDLE_ROTATE:
                            self._rotate_dragging = True
                        else:
                            self._resize_handle = h.handle_id
                        # Store starting state
                        self._resize_start_rect = QRectF(self.rect())
                        self._resize_start_pos = QPointF(self.pos())
                        self._resize_start_rot = self.rotation()
                        self._resize_start_center = self.mapToScene(
                            self._resize_start_rect.center())
                        event.accept()
                        return
        # Otherwise, default behavior (move/select)
        super().mousePressEvent(event)

    # ------------------------------------------------------ Mouse move
    def mouseMoveEvent(self, event):
        if self._resize_handle is not None:
            self._do_resize(event)
            event.accept()
        elif self._rotate_dragging:
            self._do_rotate(event)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    # ------------------------------------------------------ Mouse release
    def mouseReleaseEvent(self, event):
        if self._resize_handle is not None or self._rotate_dragging:
            self._resize_handle = None
            self._rotate_dragging = False
            # Notify scene + save
            self.parent_view.element_changed.emit(self.element)
            self.parent_view.element_layout_changed.emit(self.element)
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    # ------------------------------------------------------ Resize logic
    def _do_resize(self, event):
        """Resize based on which handle is being dragged."""
        px_per_mm = 1.0 / self.mm_per_px
        # Get the mouse position in scene coords
        mouse_scene = self.mapToScene(event.pos())
        # Convert to local (unrotated) coords — this is tricky with rotation
        # We need to undo the rotation around the start center.
        # Approach: compute the mouse position in the unrotated element's local frame.
        # The element's center in scene coords at start was _resize_start_center.
        # The element's rotation at start was _resize_start_rot.
        # To get local unrotated coords:
        #   v = mouse_scene - start_center
        #   v_local = v rotated by -start_rot
        #   local = v_local + start_rect_center (in start's local frame, which is start_rect.center())
        start_rect = self._resize_start_rect
        start_center_local = start_rect.center()
        start_center_scene = self._resize_start_center
        v = mouse_scene - start_center_scene
        # Rotate v by -start_rot (in degrees)
        angle = -self._resize_start_rot
        rad = angle * 3.14159265 / 180.0
        cos_a = __import__('math').cos(rad)
        sin_a = __import__('math').sin(rad)
        vx = v.x() * cos_a - v.y() * sin_a
        vy = v.x() * sin_a + v.y() * cos_a
        mouse_local = QPointF(vx + start_center_local.x(),
                              vy + start_center_local.y())

        # Now compute new rect based on which handle is being dragged
        hid = self._resize_handle
        r = QRectF(start_rect)
        min_size = 2.0  # px
        if hid == HANDLE_TOP_LEFT:
            r.setLeft(min(mouse_local.x(), r.right() - min_size))
            r.setTop(min(mouse_local.y(), r.bottom() - min_size))
        elif hid == HANDLE_TOP:
            r.setTop(min(mouse_local.y(), r.bottom() - min_size))
        elif hid == HANDLE_TOP_RIGHT:
            r.setRight(max(mouse_local.x(), r.left() + min_size))
            r.setTop(min(mouse_local.y(), r.bottom() - min_size))
        elif hid == HANDLE_LEFT:
            r.setLeft(min(mouse_local.x(), r.right() - min_size))
        elif hid == HANDLE_RIGHT:
            r.setRight(max(mouse_local.x(), r.left() + min_size))
        elif hid == HANDLE_BOTTOM_LEFT:
            r.setLeft(min(mouse_local.x(), r.right() - min_size))
            r.setBottom(max(mouse_local.y(), r.top() + min_size))
        elif hid == HANDLE_BOTTOM:
            r.setBottom(max(mouse_local.y(), r.top() + min_size))
        elif hid == HANDLE_BOTTOM_RIGHT:
            r.setRight(max(mouse_local.x(), r.left() + min_size))
            r.setBottom(max(mouse_local.y(), r.top() + min_size))

        # Compute new width/height in mm
        new_w_mm = r.width() / px_per_mm
        new_h_mm = r.height() / px_per_mm
        # Clamp to reasonable values
        new_w_mm = max(1.0, min(500.0, new_w_mm))
        new_h_mm = max(1.0, min(500.0, new_h_mm))
        self.element.w_mm = new_w_mm
        self.element.h_mm = new_h_mm

        # Compute new position in scene coords.
        # When resizing from a corner, the opposite corner stays fixed in scene.
        # The opposite corner in local (unrotated) start frame:
        opposite_local = QPointF()
        if hid == HANDLE_TOP_LEFT: opposite_local = start_rect.bottomRight()
        elif hid == HANDLE_TOP: opposite_local = QPointF(start_rect.center().x(), start_rect.bottom())
        elif hid == HANDLE_TOP_RIGHT: opposite_local = start_rect.bottomLeft()
        elif hid == HANDLE_LEFT: opposite_local = QPointF(start_rect.right(), start_rect.center().y())
        elif hid == HANDLE_RIGHT: opposite_local = QPointF(start_rect.left(), start_rect.center().y())
        elif hid == HANDLE_BOTTOM_LEFT: opposite_local = start_rect.topRight()
        elif hid == HANDLE_BOTTOM: opposite_local = QPointF(start_rect.center().x(), start_rect.top())
        elif hid == HANDLE_BOTTOM_RIGHT: opposite_local = start_rect.topLeft()
        # Convert opposite corner to scene coords (start)
        opposite_scene = self.mapToScene(opposite_local)
        # Now compute new center based on new w/h, with opposite corner fixed
        # The new rect in local frame (centered at origin for simplicity):
        # new_local_center is offset from opposite corner by (sign) * new_w/2, (sign) * new_h/2
        # sign depends on which corner is fixed
        signs = {
            HANDLE_TOP_LEFT: (1, 1),  # opposite is bottom-right, so new center is +w/2, +h/2 from it
            HANDLE_TOP: (0, 1),
            HANDLE_TOP_RIGHT: (-1, 1),
            HANDLE_LEFT: (1, 0),
            HANDLE_RIGHT: (-1, 0),
            HANDLE_BOTTOM_LEFT: (1, -1),
            HANDLE_BOTTOM: (0, -1),
            HANDLE_BOTTOM_RIGHT: (-1, -1),
        }
        sx, sy = signs[hid]
        # New local center (in unrotated frame) is at:
        # opposite_local + (sx * new_w_mm_px / 2, sy * new_h_mm_px / 2)
        new_w_px = new_w_mm * px_per_mm
        new_h_px = new_h_mm * px_per_mm
        new_center_local = QPointF(
            opposite_local.x() + sx * new_w_px / 2,
            opposite_local.y() + sy * new_h_px / 2,
        )
        # But wait — opposite_local is in start frame, but rotation is around center.
        # Since we keep rotation the same, the new center in scene is:
        # opposite_scene + (rotated offset from opposite to new center)
        offset_local = QPointF(new_center_local.x() - opposite_local.x(),
                                new_center_local.y() - opposite_local.y())
        # Rotate offset by start_rot
        rad2 = self._resize_start_rot * 3.14159265 / 180.0
        cos_b = __import__('math').cos(rad2)
        sin_b = __import__('math').sin(rad2)
        ox = offset_local.x() * cos_b - offset_local.y() * sin_b
        oy = offset_local.x() * sin_b + offset_local.y() * cos_b
        new_center_scene = QPointF(opposite_scene.x() + ox, opposite_scene.y() + oy)
        # New top-left in scene = new_center_scene - (new_w/2, new_h/2) rotated by start_rot
        # Actually, we need to set position (which is top-left of unrotated rect)
        # The local (0, 0) maps to: new_center_scene - (new_w/2 rotated, new_h/2 rotated)
        local_origin = QPointF(-new_w_px / 2, -new_h_px / 2)
        rad3 = self._resize_start_rot * 3.14159265 / 180.0
        cos_c = __import__('math').cos(rad3)
        sin_c = __import__('math').sin(rad3)
        ox2 = local_origin.x() * cos_c - local_origin.y() * sin_c
        oy2 = local_origin.x() * sin_c + local_origin.y() * cos_c
        new_pos_scene = QPointF(new_center_scene.x() + ox2, new_center_scene.y() + oy2)
        # Set new position
        self.element.x_mm = new_pos_scene.x() / px_per_mm
        self.element.y_mm = new_pos_scene.y() / px_per_mm
        self.setPos(new_pos_scene)
        # Update rect + transform origin
        self.setRect(QRectF(0, 0, new_w_px, new_h_px))
        self.setTransformOriginPoint(new_w_px / 2, new_h_px / 2)
        self._update_handles()
        self.update()
        self.parent_view.element_changed.emit(self.element)

    # ------------------------------------------------------ Rotate logic
    def _do_rotate(self, event):
        """Rotate the element based on angle to the rotate handle position."""
        # Get center in scene coords
        center_scene = self.mapToScene(self.rect().center())
        mouse_scene = self.mapToScene(event.pos())
        # Angle from center to mouse (in scene coords)
        import math
        v = QPointF(mouse_scene.x() - center_scene.x(),
                    mouse_scene.y() - center_scene.y())
        # Qt's angle: 0 = right (east), increases counter-clockwise (in screen coords, y is down, so it's clockwise visually)
        angle_rad = math.atan2(v.y(), v.x())
        angle_deg = angle_rad * 180 / math.pi
        # Add 90 to make "up" = 0
        new_rot = angle_deg + 90
        # Normalize to -180..180
        while new_rot > 180:
            new_rot -= 360
        while new_rot < -180:
            new_rot += 360
        self.element.rotation = new_rot
        self.setRotation(new_rot)
        self.update()
        self.parent_view.element_changed.emit(self.element)

    # ------------------------------------------------------ Keyboard
    def keyPressEvent(self, event):
        step_mm = 0.1 if (event.modifiers() & Qt.ShiftModifier) else 1.0
        step_px = step_mm * (1.0 / self.mm_per_px)
        key = event.key()
        if key == Qt.Key_Left:
            self.moveBy(-step_px, 0)
            event.accept()
        elif key == Qt.Key_Right:
            self.moveBy(step_px, 0)
            event.accept()
        elif key == Qt.Key_Up:
            self.moveBy(0, -step_px)
            event.accept()
        elif key == Qt.Key_Down:
            self.moveBy(0, step_px)
            event.accept()
        elif key == Qt.Key_Delete or key == Qt.Key_Backspace:
            self.element.enabled = False
            self.parent_view.element_changed.emit(self.element)
            self.parent_view.refresh()
            event.accept()
        else:
            super().keyPressEvent(event)


class StickerScene(QGraphicsScene):
    element_selection_changed = pyqtSignal(object)
    element_changed = pyqtSignal(object)
    element_layout_changed = pyqtSignal(object)  # emitted when resize/rotate completes

    def __init__(self, template: StickerTemplate, sample_data: dict,
                 parent=None):
        super().__init__(parent)
        self.template = template
        self.sample_data = sample_data
        self.mm_per_px = 0.25  # 1 px = 0.25 mm
        self._build_items()

    def _build_items(self):
        self.clear()
        px_per_mm = 1.0 / self.mm_per_px
        sw = self.template.sticker_w_mm * px_per_mm
        sh = self.template.sticker_h_mm * px_per_mm
        bg = QGraphicsRectItem(0, 0, sw, sh)
        bg.setBrush(QColor('#FFFFFF'))
        bg.setPen(QPen(QColor('#000000'), 0.5))
        bg.setZValue(-1)
        self.addItem(bg)
        for elem in self.template.elements:
            item = ElementItem(elem, self.mm_per_px, self)
            item.setZValue(1)
            self.addItem(item)
        self.setSceneRect(0, 0, sw, sh)

    def refresh(self):
        self._build_items()


# ---------------------------------------------------- editor dialog (legacy)
class StickerEditorDialog(QDialog):
    """Legacy dialog — kept for backwards compat. Use the inline editor in
    the main window instead."""
    def __init__(self, template: StickerTemplate, sample_data: dict,
                 sticker_w_mm: float, sticker_h_mm: float,
                 unit_code: str = 'mm',
                 parent=None):
        super().__init__(parent)
        self.template = template
        self.template.sticker_w_mm = sticker_w_mm
        self.template.sticker_h_mm = sticker_h_mm
        self.sample_data = dict(sample_data)
        self.unit = get_unit(unit_code)
        self.setWindowTitle("Sticker Layout Editor / اسٹیکر لی آؤٹ ایڈیٹر")
        self.resize(800, 600)
        v = QVBoxLayout(self)
        self.scene = StickerScene(self.template, self.sample_data)
        from PyQt5.QtWidgets import QGraphicsView
        self.view = QGraphicsView(self.scene)
        self.view.setRenderHint(QPainter.Antialiasing, True)
        v.addWidget(self.view)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        v.addWidget(btns)
