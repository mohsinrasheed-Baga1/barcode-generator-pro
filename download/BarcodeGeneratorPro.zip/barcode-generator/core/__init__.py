"""Barcode Generator core package."""
